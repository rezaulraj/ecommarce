import cloudinary from "../config/cloudinary.js";
import { redis } from "../config/redis.js";
import Product from "../models/Product.js";
import Variant from "../models/Variant.js";

export const getAllProducts = async (req, res) => {
  try {
    const products = await Product.find({}); // find all product
    res.json({ products });
  } catch (error) {
    console.log("Error message from product controller:", error.message);
    res.status(500).json({ message: "Internel server error" });
  }
};

export const getFeaturedProducts = async (req, res) => {
  try {
    let featuredProducts = await redis.get("featured_products");
    if (featuredProducts) {
      return res.json(JSON.parse(featuredProducts));
    }

    // if not in redis, fatch from mongodb
    // .lean() is gonna return a plain javascript object instead of mongodb document
    //which is good for performance

    featuredProducts = await Product.find({ isFeatured: true }).lean();
    if (!featuredProducts) {
      return res.status(404).json({ message: "No featured product found" });
    }

    // store in redis for future quick access

    await redis.set("featured_products", JSON.stringify(featuredProducts));
    res.json(featuredProducts);
  } catch (error) {
    console.log("Error in getFeaturedProducts Contorller", error.message);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

export const createProduct = async (req, res) => {
  try {
    const {
      name,
      description,
      price,
      downPrice,
      brand,
      image,
      category,
      size,
      variants,
    } = req.body;

    let cloudinaryResponse = null;

    if (image) {
      cloudinaryResponse = await cloudinary.uploader.upload(image, {
        folder: "products",
      });
    }

    const product = new Product({
      name: name.trim(),
      description: description.trim(),
      price,
      downPrice,
      brand: brand.trim(),
      image: cloudinaryResponse?.secure_url || "",
      category,
      size,
    });

    await product.save();

    res.status(201).json({ message: "Product created successfully", product });
  } catch (error) {
    console.log("Error to createProduct from productController", error.message);
    return res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

export const deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;

    // Find the product
    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json({ message: "Product not found" });
    }

    // Delete image from Cloudinary if it exists
    if (product.image) {
      const publicId = product.image.split("/").pop().split(".")[0];
      try {
        await cloudinary.uploader.destroy(`products/${publicId}`);
        console.log("Deleted image from Cloudinary");
      } catch (error) {
        console.log("Error deleting image from Cloudinary", error.message);
      }
    }

    // Remove all variants linked to this product (if you want to delete them)
    await Variant.deleteMany({ productId: product._id });

    // Finally, delete the product
    await Product.findByIdAndDelete(id);

    res
      .status(200)
      .json({ message: "Product and related variants deleted successfully" });
  } catch (error) {
    console.log("Error deleting product", error.message);
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get all variant
export const getAllVariant = async (req, res) => {
  try {
    const variant = await Variant.find({});
    return res.json({ variant });
  } catch (error) {
    console.log("Error from GetVariant controller", error.message);
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const createVariant = async (req, res) => {
  try {
    const { color, size, images, stock, price, productId } = req.body;

    let cloudinaryResponse = null;

    if (images) {
      cloudinaryResponse = await cloudinary.uploader.upload(images, {
        folder: "products",
      });
    }

    const variant = new Variant({
      color: color.trim(),
      size,
      price,
      stock,
      images: cloudinaryResponse?.secure_url || "",
      productId, // The product that this variant belongs to
    });

    await variant.save();

    // If productId exists, push the variant reference to the product's variants array
    if (productId) {
      await Product.findByIdAndUpdate(productId, {
        $push: {
          variants: variant._id, // Add variant reference to product
        },
      });
    }

    res.status(201).json({ message: "Variant created successfully", variant });
  } catch (error) {
    console.log("Error to createVariant from productController", error.message);
    return res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

export const deleteVariant = async (req, res) => {
  try {
    const { id } = req.params;

    // Find the variant
    const variant = await Variant.findById(id);
    if (!variant) {
      return res.status(404).json({ message: "Variant not found" });
    }

    // Delete image from cloudinary if it exists
    if (variant.images) {
      const publicId = variant.images.split("/").pop().split(".")[0];
      try {
        await cloudinary.uploader.destroy(`products/${publicId}`);
        console.log("Deleted image from Cloudinary");
      } catch (error) {
        console.log("Error deleting image from Cloudinary", error.message);
      }
    }

    // If the variant belongs to a product, remove this variant reference from the product
    if (variant.productId) {
      await Product.findByIdAndUpdate(variant.productId, {
        $pull: {
          variants: variant._id,
        },
      });
    }

    // Now delete the variant
    await Variant.findByIdAndDelete(id);

    res.status(200).json({ message: "Variant deleted successfully" });
  } catch (error) {
    console.log("Error deleting variant", error.message);
    res
      .status(500)
      .json({ message: "Internal server error", error: error.message });
  }
};

// Get reommendations porducet

export const getRecommendations = async (req, res) => {
  try {
    const porducts = await Product.aggregate([
      {
        $sample: { size: 3 },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          description: 1,
          image: 1,
          price: 1,
          downPrice: 1,
          brand: 1,
          size: 1,
        },
      },
    ]);
    res.json(porducts);
  } catch (error) {
    console.log("Error from getRecommendations", error.message);
    return res.status(500).json({ message: "Internal server error" });
  }
};

export const getProductsByCategorys = async (req, res) => {
  const { category } = req.params;
  try {
    const products = await Product.find({ category });
    res.json(products);
  } catch (error) {
    console.log("Error in getProductsByCategorys controller", error.message);
    return res
      .status(500)
      .json({ message: "Server Error", error: error.message });
  }
};

// toggleFeaturedProduct

export const toggleFeaturedProduct = async (req, res) => {
  const { id } = req.params.id;

  try {
    const product = await Product.findById(id);
    if (product) {
      product.isFeatured = !product.isFeatured;
      const updatedProduct = await product.save();
      await updateFeaturedProductsCashe();
      res.json(updatedProduct);
    } else res.status(404).json({ message: "Product not found" });
  } catch (error) {
    console.log("Error from toggleFeaturedProduct controller", error.message);
    return res.status({
      message: "Internal server error",
      error: error.message,
    });
  }
};

async function updateFeaturedProductsCashe() {
  try {
    const featuredProducts = await Product.find({ isFeatured: true }).lean();
    await redis.set("featured_products".JSON.stringify(featuredProducts));
  } catch (error) {
    console.log("error in update redis cash");
  }
}
